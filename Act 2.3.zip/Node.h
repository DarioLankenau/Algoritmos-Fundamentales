//
// Created by dario on 07/10/2020.
//

#ifndef UNTITLED8_NODE_H
#define UNTITLED8_NODE_H
#include <iostream>
using namespace std;

struct info{
    long key;
    string month;
    long day;
    string hour;
    string iP;
    string message;
};

class Node{
public:
    Node(info data);
    Node(info data, Node *next, Node *prev);
    info getData();
    Node* getNext();
    Node* getPrev();
    void setData(info data);
    void setNext(Node *next);
    void setPrev(Node *prev);
private:
    info data;
    Node *prev;
    Node *next;
};


Node::Node(info data){
    this->data = data;
    this->next = nullptr;
    this->prev = nullptr;
}


Node::Node(info data, Node* next, Node *prev){
    this->data = data;
    this->next = next;
    this->prev = prev;
}


info Node::getData(){
    return data;
}


Node* Node::getNext(){
    return next;
}

void Node::setData(info data){
    this->data = data;
}

void Node::setNext(Node *next){
    this->next = next;
}

Node* Node::getPrev(){
    return prev;
}

void Node::setPrev(Node *prev){
    this->prev = prev;
}
#endif //UNTITLED8_NODE_H
