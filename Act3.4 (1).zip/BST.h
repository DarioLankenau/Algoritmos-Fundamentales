# include <iostream>
# include <cstdlib>
#include "Node.h"
#include <vector>
#include "stack"

using namespace std;

class BST{
  
   public:
   BST();
   void add(info data);
   void iOrder(Node *r);
   void preOrden(Node *r);
   void printPre();
   void visit();
   void verify(vector <long> vec);
   void search(long data);

   private:
   Node *root;
};

BST::BST(){
    root = nullptr;
}

// Complejidad: O(altura del árbol)
void BST::add(info data){
	Node *curr = root;
	Node *father = nullptr;
	while (curr != nullptr){
		if (curr->getData().key == data.key){
			return;
		}
		father = curr;
		curr = (curr->getData().key > data.key) ? curr->getLeft() : curr->getRight();
	}
	if (father == nullptr){
		root = new Node(data);
	}
	else{
		(father->getData().key > data.key) ? father->setLeft(new Node(data)) : father->setRight(new Node(data));
	}

}


void BST::visit(){
    iOrder(root);
}

//Complejidad: O(n)
void BST::preOrden(Node *r){
	if (r != nullptr){
		cout << r->getData().key << " ";
		preOrden(r->getLeft());
		preOrden(r->getRight());
	}
}

//Complejidad: O(n)
void BST::printPre(){
	iOrder(root);
	cout << endl;
}

void BST::iOrder(Node *root) 
{ 
    stack<Node *> s; 
    Node *curr = root; 
    vector <long> vec;
  
    while (curr != nullptr || s.empty() == false) 
    { 
        while (curr !=  nullptr) 
        { 
            s.push(curr); 
            curr = curr->getLeft(); 
        } 
  
        curr = s.top(); 
        s.pop(); 

        vec.push_back(curr->getData().key);
        
        curr = curr->getRight(); 
    }

      int n = 5;
      vector<long> y(vec.end() - n, vec.end());
      cout << "Ip's con más repeticiones" << endl;
      for (int i=0;i<5;i++){
        cout << y[i]<<endl;
      }
} 

void BST::verify(vector <long> vec){
    cout << vec[0];
}

// Complejidad: O(altura del árbol)
void BST::search(long data){
    Node *curr = root;
    while (curr != nullptr){
        if (curr->getData().key == data){
            cout << curr->getData().iP;
        }
        if (curr->getData().key > data){
            curr = curr->getLeft();
        }
        else{
            curr = curr->getRight();
        }
        curr = (curr->getData().key > data) ? curr->getLeft() : curr->getRight();
    }
}