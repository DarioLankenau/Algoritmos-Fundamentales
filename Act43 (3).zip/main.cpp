// Dario Jauregui A00827837
// Jose Andres Villarreal A00829355

#include <iostream>
#include <unordered_map>
#include <fstream>
#include <vector>
#include <iterator>
#include <algorithm>

using namespace std;

// Complejidad O(n)
long ipToLong(string ip){
	int idx = 0;
	long datoFinal= 0, dato = 0;
	while (idx < ip.size()){
		if (ip[idx]!= '.' && ip[idx]!=':'){
			dato = dato*10 + ip[idx]-'0';
		}
		else{
			datoFinal = datoFinal*1000 + dato;
			dato = 0;
		}
		idx++;
	}
	datoFinal = datoFinal*10000 + dato;
	return datoFinal;
}

// Complejidad O(n)
string ignoraPuerto(string ip){
    int idx = 0;
    string iplimpia;
    while(idx < ip.size() && ip[idx]!= ':'){
        iplimpia = iplimpia + ip[idx++];
    }
    return iplimpia;
}

// Complejidad O(n)
void loadGraph(){
  ifstream file;
  file.open("bitacora.txt");

  string mes, dia, hora, ipentra, ipsale, razon;
  int maxRepeticiones = 0;
  long n, m;
  file >> n >> m;


  vector<vector<int>> listAdj(n);

  unordered_map<string, pair<int, int>> nodos_ips;

  string ip;
  for(int i=0; i<n; i++){
      file >> ip;
      pair<int, int> uno;
      uno.first = i; //Num de nodo
      uno.second = 0; //Outdegree
      nodos_ips[ip] = uno;
  }

  for(int j=0; j<m; j++){
      file>>mes>>dia>>hora>>ipentra>>ipsale;
      getline(file,razon);

      ipentra = ignoraPuerto(ipentra);
      ipsale = ignoraPuerto(ipsale);

      //cout << ipentra << ", " << ipsale << endl;

      int numNodoSale = nodos_ips[ipsale].first;
      int numNodoEntra = nodos_ips[ipentra].first;
      nodos_ips[ipentra].second++;

      if(nodos_ips[ipentra].second > maxRepeticiones){
          maxRepeticiones = nodos_ips[ipentra].second;
      }

      listAdj[numNodoSale].push_back(numNodoEntra);
      listAdj[numNodoEntra].push_back(numNodoSale);

  }

  unordered_map<string, pair<int, int>>::iterator k;
  vector<string> ips_rep;
  string ip_repetida;

cout << " ------------------------------------------ " << endl;
cout << " IPs con mayores Fan-outs" << endl;
cout << " ------------------------------------------ " << endl;
  for(k = nodos_ips.begin(); k != nodos_ips.end(); k++){
      if((k->second).second == maxRepeticiones){
          cout << k->first << "," << (k->second).second << endl;
      }
  }
}

int main() {
  loadGraph();
}

