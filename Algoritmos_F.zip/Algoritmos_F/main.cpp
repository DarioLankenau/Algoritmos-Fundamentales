/* 

11/09/2020

Dario Jauregui A00827837
José Andrés Villarreal A00829355

Actividad 1.3 

*/
#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

struct info{
    long long key;
    string month;
    long long day;
    string hour;
    string iP;
    string message;
};

// Lee información del archivo .txt y lo almacena en un vector de struct
void readData(vector<info> &vec){
    long long day, key, count = 0;
    string month,hour,iP,message;
    ifstream file;
    file.open("bitacora.txt");

    while(file >> month >> day >> hour >> iP){
        getline(file,message);
        vec.emplace_back(info());
        vec[count].month = month;
        vec[count].day = day;
        vec[count].hour = hour;

        // Se crea una "key" que sirve para pasar de string a int los meses y días y asi identificarlos posteriormente

        if(month == "Jun"){
          vec[count].key = 600 + day;
        }else if(month=="Jul"){
          vec[count].key = 700 + day;
        }else if(month=="Aug"){
          vec[count].key = 800 + day;
        }else if(month=="Sep"){
          vec[count].key = 900 + day;
        }else if(month=="Oct"){
          vec[count].key = 1000 + day;
        }
        vec[count].iP = iP;
        vec[count].message = message;
        count++;
    }

    file.close();
}

// Complejidad O(n) une vectores dados por el Merge sort
void une(vector<info> &vec, long long ini, long long m, long long fin){
  vector <info> aux(vec.size());
    long long i = ini, j = m+1, k = ini;
    while (i<=m && j <=fin){
        if (vec[i].key <= vec[j].key){
            aux[k++] = vec[i++];
        }
        else {
            aux[k++] = vec[j++];
        }
    }
    while (i<=m){
        aux[k++] = vec[i++];
    }
    while (j<= fin){
        aux[k++] = vec[j++];
    }
    for (int z=ini;z<=fin;z++){
        vec[z] = aux[z];
    }
}

// Complejidad O(n log n) Ordena en forma ascendente los datos con el método de Merge
void ordenaMerge(vector<info> &vec,  long long ini, long long fin) {

    if (ini < fin) {
        long long m = (ini + fin) / 2;
        ordenaMerge(vec, ini, m);
        ordenaMerge(vec, m + 1, fin);
        une(vec, ini, m, fin);
    }
}

// Complejidad O(log2n) Busca con la búsqueda binaria un dato entero dentro del vector
void busqBinaria(vector<info> &vec, int n) {
    ofstream Archivo("registros.txt",std::ios::app); // Se abre y crea un archivo nuevo con el nombre de registros.txt
    int start = 0, end = vec.size()-1, mid, cont = 0;
    bool found = false;
    while (start <= end) {
        mid = start+((end-start) / 2);

        if (vec[mid].key == n) {
            found = true;
          cout << vec[mid].key << endl;
          cout << vec[mid].month << endl;
          cout << vec[mid].day << endl;
          cout << vec[mid].hour << endl;
          cout << vec[mid].iP << endl;
          cout << vec[mid].message << endl;
          cout << endl;

          Archivo << vec[mid].key << endl;
          Archivo << vec[mid].month << endl;
          Archivo << vec[mid].day << endl;
          Archivo << vec[mid].hour << endl;
          Archivo << vec[mid].iP << endl;
          Archivo << vec[mid].message << endl;
          Archivo << endl;

        }

        if (vec[mid].key > n) {
            end = mid - 1;
        } else {
            start = mid + 1;
        }

    }
    Archivo.close();
}

int main() {
    int inicio, final, n = 0;
    vector<info> vec;
    readData(vec);

    ordenaMerge(vec,0,vec.size()-1);

    cout << "ingresa la fecha inicial con el siguiente formato: Junio 20 es 620, Agosto 28 es 828, Octubre 6 es 1006, etc..." << endl;
    cin >> inicio;

    cout << "Ingresa la fecha final con el siguiente formato: Junio 20 es 620, Agosto 28 es 828, Octubre 6 es 1006, etc..." << endl;
    cin >> final;

    n = inicio;

    for (int i =n; i<=final; i++){
      busqBinaria(vec, n);
      n++;
    }

  return 0;
}
