// Dario Jauregui A00827837
// Jose Andres Villarreal A00829355

#include <iostream>
#include <unordered_map>
#include <fstream>
#include <vector>
#include <iterator>
#include <algorithm>

using namespace std;

struct datos{
    string dia;
    string mes;
    string hora;
    string razon; 
};

// Complejidad O(n)
string ignoraPuerto(string ip){
    int idx = 0;
    string iplimpia;
    while(idx < ip.size() && ip[idx]!= ':'){
        iplimpia = iplimpia + ip[idx++];
    }
    return iplimpia;
}

// Complejidad O(n)
void imprimeDatos(unordered_map<string, vector<datos>> mapaIPs){
    string opc;
    cout << "Inserte una IP valida" << endl;
    cin >> opc;
    cout << "Ip: " << opc << endl;
    cout << "N. accesos: " << mapaIPs[opc].size() << endl;
    cout << "Accesos Encontrados: " << endl;
    for(int i=0; i<mapaIPs[opc].size(); i++){
      cout << mapaIPs[opc][i].mes << " " << mapaIPs[opc][i].dia << " " << mapaIPs[opc][i].razon << endl;
    }
}

// Complejidad O(1)
void createMap(){
  ifstream file;
  file.open("bitacoraACT5_2.txt");

  string mes, dia, hora, ip, razon;
  datos data2;

  unordered_map<string, vector<datos>> mapaIPs;

  while(file >> mes >> dia >> hora >> ip){
        getline(file, razon);
        ip = ignoraPuerto(ip);
        data2.mes = mes;
        data2.dia = dia;
        data2.hora = hora;
        data2.razon = razon;
        mapaIPs[ip].push_back(data2);
    }

    imprimeDatos(mapaIPs);
}

int main() {
  createMap();
}